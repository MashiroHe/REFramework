﻿/********************************************************************
version:  1.0.2
created:  2024/03/07 10:37
filename: RESession.cs
author:	  Mashiro
e-mail:   1967407707@qq.com
purpose:   
********************************************************************/
using REUtils.LogTool;
using REUtils.SerializeTool;
using System;
using System.Collections.Generic;
using System.Net.Sockets;

namespace RENet.TCP
{
    public abstract class RESession<TMsg> where TMsg : class, new()
    {
        #region Private Field

        private Socket m_Socket = null;
        private Action m_CloseAction = null;

        #endregion

        #region Public Properties

        public Socket Socket
        {
            get
            {
                return this.m_Socket;
            }
            private set
            {
                this.m_Socket = value;
            }
        }
        public Action CloseAction
        {
            get
            {
                return this.m_CloseAction;
            }
            private set
            {
                this.m_CloseAction = value;
            }
        }
        #endregion

        #region Public Method

        public void ReciveMsgAsync(Socket socket, Action closeAction = null)
        {
            this.Socket = socket;
            this.CloseAction = closeAction;
            this.OnConnected();
            try
            {
                REPackage package = new REPackage();
                this.Socket.BeginReceive(package.HeadBuffer, 0, package.HeadLength, SocketFlags.None, new AsyncCallback(this.OnRecive_HeadDataCallback), package);
            }
            catch (Exception e)
            {
                RELog.Log("StartReciveDataError:" + e.ToString());
                this.Close();
            }
        }

        public void SendMsgAsync(TMsg msg)
        {
            byte[] originData = RESerialize.SerializeProtoMsg<TMsg>(msg);
            byte[] datas = CreatePackageData(originData);
            this.WriteData_Async(this.Socket, datas);
        }

        public void SendMsgAsync(byte[] datas)
        {
            this.WriteData_Async(this.Socket, datas);
        }

        public void SendMsgToAll<TSession>(List<TSession> sessions, TMsg msg) where TSession : RESession<TMsg>
        {
            byte[] originData =  RESerialize.SerializeProtoMsg<TMsg>(msg);
            byte[] datas =  CreatePackageData(originData);
            bool flag = sessions.Count > 0;
            if (flag)
            {
                foreach (TSession tsession in sessions)
                {
                    tsession.SendMsgAsync(datas);
                }
            }
            else
            {
                 RELog.Log("当前无客户端连接！");
            }
        }

        public void Dispose()
        {
            this.Close();
        }

        #endregion

        #region Private Method

        private void OnRecive_HeadDataCallback(IAsyncResult result)
        {
            try
            {
                if (this.Socket != null || this.Socket.Connected == true)
                {
                    REPackage package = (REPackage)result.AsyncState;
                    int count = this.Socket.EndReceive(result);
                    if (count > 0)
                    {
                        package.HeadIndex += count;
                        //头数据没有接收完成，则继续接收数据
                        if (package.HeadIndex < package.HeadLength)
                        {
                            int size = package.HeadLength - package.HeadIndex;
                            this.Socket.BeginReceive(package.HeadBuffer, package.HeadIndex, size, SocketFlags.None, new AsyncCallback(this.OnRecive_HeadDataCallback), package);
                        }
                        //接收完成，则接收实际传输数据
                        else
                        {
                            // 根据头数据 初始化实际接收数据的缓存器大小
                            package.Init_BodyBuffer();
                            // RELog.Log("本条传输的数据总长度为：" + package.BodyLength.ToString());
                            this.Socket.BeginReceive(package.BodyBuffer, 0, package.BodyLength, SocketFlags.None, new AsyncCallback(this.OnRecive_BodyDataCallback), package);
                        }
                    }
                    else
                    {
                         RELog.Log("客户端断开服务器连接成功！");
                        this.Close();
                    }
                }
            }
            catch (Exception e)
            {
                 RELog.Log("OnRecive_HeadDataCallbackError" + e.ToString());
                this.Close();
            }
        }

        private void OnRecive_BodyDataCallback(IAsyncResult result)
        {
            try
            {
                if (this.Socket != null || this.Socket.Connected == true)
                {
                    REPackage package = (REPackage)result.AsyncState;
                    int count = this.Socket.EndReceive(result);
                    if (count > 0)
                    {
                        package.BodyIndex += count;
                        //数据没有接收完成，则继续接收数据
                        if (package.BodyIndex < package.BodyLength)
                        {
                            int size = package.BodyLength - package.BodyIndex;
                            this.Socket.BeginReceive(package.BodyBuffer, package.BodyIndex, size, SocketFlags.None, new AsyncCallback(this.OnRecive_BodyDataCallback), package);
                        }
                        //接收完成，则处理实际传输数据
                        else
                        {
                            TMsg msg =  RESerialize.DeserializeProtoMsg<TMsg>(package.BodyBuffer);
                            if (msg != null)
                            {
                                this.OnRecivedMsg(msg);
                            }
                            // RELog.Log("本条数据接收完成！");
                            package.Reset();
                            this.Socket.BeginReceive(package.HeadBuffer, 0, package.HeadLength, SocketFlags.None, new AsyncCallback(this.OnRecive_HeadDataCallback), package);
                        }
                    }
                    else
                    {
                         RELog.Log("客户端断开服务器连接成功！" + count.ToString());
                        this.Close();
                    }
                }
            }
            catch (Exception e)
            {
                 RELog.Log("OnRecive_BodyDataCallbackError" + e.ToString());
                this.Close();
            }
        }

        private void WriteData_Async(Socket socket, byte[] datas)
        {
            try
            {
                NetworkStream networkStream = new NetworkStream(socket);
                bool canWrite = networkStream.CanWrite;
                if (canWrite)
                {
                    networkStream.BeginWrite(datas, 0, datas.Length, new AsyncCallback(this.OnBegainWriteDataCallBack), networkStream);
                }
            }
            catch (Exception e)
            {
                 RELog.Log("WriteData_AsyncError" + e.ToString());
            }
        }

        private void OnBegainWriteDataCallBack(IAsyncResult result)
        {
            NetworkStream networkStream = result.AsyncState as NetworkStream;
            try
            {
                networkStream.EndWrite(result);
                networkStream.Flush();
                networkStream.Close();
            }
            catch (Exception e)
            {
                 RELog.Log("OnBegainWriteDataCallBackError" + e.ToString());
            }
        }

        private byte[] CreatePackageData(byte[] originData)
        {
            int originDataLength = originData.Length;
            int headLength = 4;
            //创建 数据包数组
            byte[] package = new byte[headLength + originDataLength];
            //得到数据头数据
            byte[] headData = BitConverter.GetBytes(originDataLength);
            //存入数据头数据
            headData.CopyTo(package, 0);
            //存入实际传输数据
            originData.CopyTo(package, headLength);
            return package;
        }

        private void Close()
        {
            this.OnDisConnected();
            if (this.CloseAction != null)
            {
                this.CloseAction();
            }
            bool flag = this.Socket != null;
            if (flag)
            {
                this.Socket.Shutdown(SocketShutdown.Both);
                this.Socket.Close();
                this.Socket = null;
            }
        }


        #endregion

        #region Virtual Method

        protected virtual void OnRecivedMsg(TMsg message)
        {
           
             RELog.Log("RecivedMsg：" + message);
        }

        protected virtual void OnConnected()
        {
             RELog.Log("New Session Connected 连接成功！");
        }

        protected virtual void OnDisConnected()
        {
             RELog.Log("Session Connected 断开连接成功！", LogType.Warning);
        }
        #endregion
    }

}
