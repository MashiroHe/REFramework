﻿/********************************************************************
version:  1.0.2
created:  2024/03/07 10:37
filename: REPackage.cs
author:	  Mashiro
e-mail:   1967407707@qq.com
purpose:   
********************************************************************/
using System;

namespace RENet.TCP
{
    public class REPackage
    {
        /*数据头*/
        //一条数据的 字节头数据缓存长度大小
        private const int m_HeadLength = 4;
        //一条数据的 字节头数据缓存数组buffer
        private byte[] m_HeadBuffer = null;
        //一条数据 字节头数据 已被接收字节头数据的索引
        private int m_HeadIndex = 0;

        /*数据体*/
        //实际接收到的数据的长度
        private int m_BodyLength = 0;
        //实际接收数据的缓存数组buffer
        private byte[] m_BodyBuffer = null;
        //实际接收到的数据的当前索引
        private int m_BodyIndex = 0;

        /*数据头*/
        public int HeadLength { get => m_HeadLength; }
        public byte[] HeadBuffer { get => this.m_HeadBuffer; set => this.m_HeadBuffer = value; }
        public int HeadIndex { get => this.m_HeadIndex; set => this.m_HeadIndex = value; }

        /*数据体*/
        public int BodyLength { get => this.m_BodyLength; set => this.m_BodyLength = value; }
        public byte[] BodyBuffer { get => this.m_BodyBuffer; set => this.m_BodyBuffer = value; }
        public int BodyIndex { get => this.m_BodyIndex; set => this.m_BodyIndex = value; }

        public REPackage()
        {
            this.m_HeadBuffer = new byte[m_HeadLength];
        }
        public void Init_BodyBuffer()
        {
            //初始化实际要接收的数据的长度
            this.m_BodyLength = BitConverter.ToInt32(m_HeadBuffer, 0);
            this.m_BodyBuffer = new byte[m_BodyLength];
        }
        public void Reset()
        {
            //数据头
            this.m_HeadIndex = 0;
            //数据体
            this.m_BodyLength = 0;
            this.m_BodyBuffer = null;
            this.m_BodyIndex = 0;
        }
    }

}
