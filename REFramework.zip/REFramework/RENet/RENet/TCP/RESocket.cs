﻿/********************************************************************
version:  1.0.2
created:  2024/03/07  10:55
filename: RESocket.cs
author:	  Mashiro 
e-mail:   1967407707@qq.com
purpose:   
********************************************************************/
using System;
using System.Net.Sockets;
using System.Net;
using System.Collections.Generic;
using REUtils.LogTool;

namespace RENet.TCP
{
    public class RESocket<TSession, TMsg> where TSession : RESession<TMsg>, new() where TMsg : class, new()
    {
        #region Private Field
        private Socket m_Socket = null;

        //客户端服务器 公用Session
        private TSession m_Session = default(TSession);// null;
        //存储所有连接服务器的客户端Session
        private List<TSession> m_Sessions = null;


        #endregion

        #region Public Properties

        public Socket Socket { get => m_Socket; private set => m_Socket = value; }
        public TSession Session { get => m_Session; private set => m_Session = value; }
        public List<TSession> Sessions { get => m_Sessions; private set => m_Sessions = value; }

        #endregion
        public RESocket()
        {
            Socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        }

        #region Public Method

        /*客户端*/
        /// <summary>
        ///客户端要连接的服务器绑定的ip地址和端口号 m_IPAdress = "127.0.0.1";  m_Port = 17666;
        /// </summary>
        public void InitAsClient(string ipAddress, int port)
        {
             RELog.Log("Init Client...");
            try
            {
                //链接指定的 IP地址和端口号
                EndPoint endPoint = new IPEndPoint(IPAddress.Parse(ipAddress), port);
                //客户端 异步 连接 服务器
                Socket.BeginConnect(endPoint, OnBegainConnectServerCallback, Socket);
            }
            catch (Exception e)
            {
                 RELog.Log("InitAsClientError" + e.ToString(), LogType.Error);
            }
        }


        /*服务器*/
        /// <summary>
        /// 服务器要绑定的ip地址和端口号
        /// </summary>
        /// <param name="ipAddress"></param>
        /// <param name="port"></param>
        public void InitAsServer(string ipAddress, int port, int listenCount = 100)
        {
             RELog.Log("Init Server...");
            try
            {
                //初始化缓存会话列表
                Sessions = new List<TSession>();
                //服务器绑定IP地址和端口号
                EndPoint endPoint = new IPEndPoint(IPAddress.Parse(ipAddress), port);
                Socket.Bind(endPoint);
                //设置 端口号最大监听 数量
                Socket.Listen(listenCount);
                //Log("Server is Begin Accept Client connect...");
                //多线程异步等待连接
                Socket.BeginAccept(OnAcceptClient_ConnectCallback, Socket);
            }
            catch (Exception e)
            {
                 RELog.Log("InitAsServerError" + e.ToString(), LogType.Error);
            }
        }

        public void Dispose(bool isSever = true)
        {
            /*客户端*/
            if (isSever == false)
            {
                if (Session != null)
                {
                    //释放资源关闭连接的Socket
                    Session.Dispose();
                    Session = default(TSession);//null
                }
                //清空引用
                if (Socket != null)
                {
                    Socket = null;
                }
            }
            /*服务器*/
            else
            {
                if (Sessions.Count > 0)
                {
                    for (int i = 0; i < Sessions.Count; i++)
                    {
                        Sessions[i].Dispose();
                    }
                    Sessions.Clear();
                    Sessions = null;
                }
                //清空引用
                if (Socket != null)
                {
                    Socket.Close();
                    Socket = null;
                }
            }

        }
        #endregion

        #region Private Method
        /*客户端*/
        private void OnBegainConnectServerCallback(IAsyncResult result)
        {
            try
            {
                Socket clientSocket = result.AsyncState as Socket;
                //结束当前 客户端异步连接
                //Log("Client is End Connect");
                clientSocket.EndConnect(result);

                 RELog.Log("Client is Connect Server Success!", LogType.Accent);
                //创建连接通信会话 接收传递的数据包：由 数据头和数据体组成 
                Session = Activator.CreateInstance<TSession>();// new TSession();
                Session.ReciveMsgAsync(clientSocket, null);
            }
            catch (Exception e)
            {
                 RELog.Log("OnBegainConnectServerCallbackError" + e.ToString(), LogType.Error);
            }
        }

        /*服务器*/
        private void OnAcceptClient_ConnectCallback(IAsyncResult result)
        {
            try
            {
                //获取执行回调函数  传递的参数数据
                Socket socket = result.AsyncState as Socket;
                //然后结束 接受连接,返回 连接成功的新Socket 以便 开始与连接的客户端进行通讯 
                //Log("Server is End Accept Client connect...");
                Socket clientSocket = socket.EndAccept(result);

                TSession session = Activator.CreateInstance<TSession>();// new TSession();
                //客户端连接服务器的Session,这个Session可能随着不同客户端连接而改变
                Session = session;
                //缓存连接成功的当前会话
                Sessions.Add(session);

                //服务器 开始异步接收连接成功 客户端数据
                session.ReciveMsgAsync(clientSocket, delegate
                {
                    if (Sessions.Contains(session))
                    {
                        Sessions.Remove(session);
                    }
                });

                //Log("Server is Begin Accept New Client connect...");
                //递归等待新的客户端连接
                socket.BeginAccept(OnAcceptClient_ConnectCallback, socket);
            }
            catch (Exception e)
            {
                 RELog.Log("OnAcceptClient_ConnectCallbackError" + e.ToString(), LogType.Error);
            }
        }
        #endregion
    }

}
