﻿using RENet.TCP;
using REUtils.LogTool;
using REUtils.SerializeTool;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;

namespace RENet.UDP
{
    public abstract class RESession<TMsg> where TMsg : class, new()
    {
        #region Private Field

        private UdpClient m_UDP;
        private IPEndPoint m_RemotePoint;

        private Action m_CloseAction = null;

        #endregion
       
        #region Public Properties

        public Action CloseAction
        {
            get
            {
                return this.m_CloseAction;
            }
            private set
            {
                this.m_CloseAction = value;
            }
        }

        public IPEndPoint RemotePoint { get => m_RemotePoint;private set => m_RemotePoint = value; }
        public UdpClient UDP { get => m_UDP; set => m_UDP = value; }
       
        #endregion

        #region Public Method
        public void Connected()
        {
            this.OnConnected();
        }
        public  void HandleMsg(byte[] datas, IPEndPoint remotePoint)
        {
            this.RemotePoint = remotePoint;
            TMsg pack = RESerialize.DeserializeProtoMsg<TMsg>(datas);// RESerialize.DeserializeMsg<MsgPack>(data);
            OnRecivedMsg(pack, remotePoint);
        }
      
        public void SendMsg(TMsg msgPack, IPEndPoint iPEndPoint)
        {
            //序列化消息 SerializeProtoMsg =28个字节  
            byte[] pack = RESerialize.SerializeProtoMsg(msgPack);// RESerialize.SerializeMsg(msgPack);
            if (m_UDP != null)
            {
                m_UDP.Send(pack, pack.Length, iPEndPoint);
            }
        }


        public void SendMsgAsync(TMsg msgPack, IPEndPoint iPEndPoint)
        {
            byte[] pack = RESerialize.SerializeProtoMsg(msgPack);// RESerialize.SerializeMsg(msgPack);
            if (m_UDP != null)
            {
                m_UDP.SendAsync(pack, pack.Length, iPEndPoint);
            }
        }

        public void SendMsgToAll<TSession>(List<TSession> sessions, TMsg msg) where TSession : RESession<TMsg>
        {
            byte[] pack = RESerialize.SerializeProtoMsg<TMsg>(msg);
            if (sessions.Count > 0)
            {
                if (m_UDP != null)
                {
                    foreach (TSession session in sessions)
                    {
                        m_UDP.Send(pack, pack.Length,session.RemotePoint);
                    }
                }
            }
            else
            {
                RELog.Log("当前无客户端连接！");
            }
        }
        public void SendMsgToAllAsync<TSession>(List<TSession> sessions, TMsg msg) where TSession : RESession<TMsg>
        {
            byte[] pack = RESerialize.SerializeProtoMsg<TMsg>(msg);
            if (sessions.Count > 0)
            {
                if (m_UDP != null)
                {
                    foreach (TSession session in sessions)
                    {
                        m_UDP.SendAsync(pack, pack.Length, session.RemotePoint);
                    }
                }
            }
            else
            {
                RELog.Log("当前无客户端连接！");
            }
        }

        public void Dispose()
        {
            this.Close();
        }

        #endregion

        #region Private Method
       private void Close()
        {
            this.OnDisConnected();
            if (this.CloseAction != null)
            {
                this.CloseAction();
            }
          
            if (this.UDP != null)
            {
                this.UDP.Close();
                this.UDP = null;
            }
        }


        #endregion

        #region Virtual Method
        protected virtual void OnConnected()
        {
            RELog.Log("New Session Connected 连接成功！");
        }

        protected virtual void OnDisConnected()
        {
            RELog.Log("Session Connected 断开连接成功！", LogType.Warning);
        }

        protected virtual void OnRecivedMsg(TMsg msgPack, IPEndPoint  iPEndPoint)
        {
            RELog.Log("RecivedMsg：" + msgPack);
        }

        #endregion
    }

}
