﻿

using REUtils.LogTool;
using System.Collections.Generic;
using System;
using System.Net;
using System.Net.Sockets;
using System.Threading.Tasks;


namespace RENet.UDP
{
    public class RESocket<TSession, TMsg> where TSession : RESession<TMsg>, new() where TMsg :  class, new()
    {
        #region Private Field
        private UdpClient m_UDP;
        private IPEndPoint m_IPEndPoint;
        private int m_Port;
        //客户端服务器 公用Session
        private TSession m_Session = default(TSession);// null;
        //存储所有连接服务器的客户端Session
        private List<TSession> m_Sessions = null;


        #endregion

        #region Public Properties

        public UdpClient UDP
        {
            get => m_UDP;
            private set => m_UDP = value;
        }
        public TSession Session { get => m_Session; private set => m_Session = value; }
        public List<TSession> Sessions { get => m_Sessions; private set => m_Sessions = value; }

        #endregion
        public RESocket(IPEndPoint ipEndPoint) 
        {
            m_IPEndPoint = ipEndPoint;
        }
        public RESocket(int port=0)
        {
            m_Port = port;
        }

        #region Public Method
        public void Init(bool isServer=true)
        {
            try
            { 
                /*服务器*/
                if (isServer==true)
                {
                    RELog.Log("Init UDP Server...");
                    m_UDP = new UdpClient(m_IPEndPoint);
                    m_Sessions= new List<TSession>();
                }
                /*客户端*/
                else
                {
                    RELog.Log("Init UDP Client...");
                    //设置为 0 ，则客户端发送端口由操作系统动态决定,否则的发送自身IP地址喝端口号
                    m_UDP = new UdpClient(m_Port);

                }
                //创建会话
                Session = new TSession();
                Session.UDP = m_UDP;
                //客户端 异步 连接 服务器
                //异步接收数据
                Task.Run(OnReciveDataAsync); 
            }
            catch (Exception e)
            {
                RELog.Log("InitAsClientError" + e.ToString(), LogType.Error);
            }
        }

        public void Dispose(bool isSever = true)
        {
            /*客户端*/
            if (isSever == false)
            {
                if (Session != null)
                {
                    //释放资源关闭连接的Socket
                    Session.Dispose();
                    Session = default(TSession);//null
                }
                //清空引用
                if (UDP != null)
                {
                    UDP = null;
                }
            }
            /*服务器*/
            else
            {
                if (Sessions.Count > 0)
                {
                    for (int i = 0; i < Sessions.Count; i++)
                    {
                        Sessions[i].Dispose();
                    }
                    Sessions.Clear();
                    Sessions = null;
                }
                //清空引用
                if (UDP != null)
                {
                    UDP.Close();
                    UDP = null;
                }
            }

        }
        #endregion

        #region Private Method
      
        private async void OnReciveDataAsync()
        {
            Session.Connected();
            UdpReceiveResult result;
            while (true)
            {
                result = await m_UDP.ReceiveAsync();
                byte[] datas = result.Buffer;

                //客户端IP
                IPEndPoint remotePoint = result.RemoteEndPoint;
                RELog.Log(" Recived RemoteEndPoint:" + remotePoint);
               
                Session.HandleMsg(datas,  remotePoint);
               
                //服务器需要存储所有连接客户端
                if(Sessions!=null)
                {
                    if (!Sessions.Contains(Session))
                    {
                        Sessions.Add(Session);
                    }
                }
              
            }
        }

        #endregion
    }

   
}
