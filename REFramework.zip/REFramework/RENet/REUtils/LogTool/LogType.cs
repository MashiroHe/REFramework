﻿/*********************************************************************
version:  1.0.2
created:  2024/03/20 11:54
filename: LogType.cs
author:	  Mashiro
e-mail:   1967407707@qq.com
purpose:  
********************************************************************/
namespace REUtils.LogTool
{
    public enum LogType
    {
        None,
        Normal,
        Accent,
        Warning,
        Error,
    }
}
