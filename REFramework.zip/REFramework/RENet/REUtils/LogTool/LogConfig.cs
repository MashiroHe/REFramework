﻿/*********************************************************************
version:  1.0.2
created:  2024/03/20 11:54
filename: LogConfig.cs
author:	  Mashiro
e-mail:   1967407707@qq.com
purpose:  
********************************************************************/

using System;

namespace REUtils.LogTool
{
    public class LogConfig
    {
        public string savePath
        {
            get
            {
                if (this._savePath == null)
                {
                    if (this.loggerEnum == LogPlatformType.Unity)
                    {
                        Type type = Type.GetType("UnityEngine.Application, UnityEngine");
                        this._savePath = type.GetProperty("persistentDataPath").GetValue(null).ToString() + "/PELog/";
                    }
                    else
                    {
                        this._savePath = string.Format("{0}Logs\\", AppDomain.CurrentDomain.BaseDirectory);
                    }
                }
                return this._savePath;
            }
            set
            {
                this._savePath = value;
            }
        }


        public bool enableLog = true;


        public string logPrefix = "*[";//"#";
        public string logPostfix = "]";//"#";

        public bool enableTime = true;


        public string logSeparate = ":";// ">>";


        public bool enableThreadID = true;


        public bool enableTrace = true;


        public bool enableSave = true;


        public bool enableCover = true;


        private string _savePath;


        public string saveName = "PELog.txt";


        public LogPlatformType loggerEnum = LogPlatformType.Console;


        public Action<int> GetFrameIndex;
    }

}
