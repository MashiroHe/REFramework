﻿/*********************************************************************
version:  1.0.2
created:  2024/03/20 11:54
filename: RELog.cs
author:	  Mashiro
e-mail:   1967407707@qq.com
purpose:  
********************************************************************/
using System;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Threading;

namespace REUtils.LogTool
{
    public static class RELog
    {
        #region 需要先初始化 使用
        public static void Init(LogPlatformType loggerEnum)
        {
            RELog.logConfig = new LogConfig
            {
                loggerEnum = loggerEnum
            };
            RELog.Init( RELog.logConfig);
        }


        public static void Init(LogConfig cfg)
        {
            RELog.logConfig = cfg;
            if (cfg.loggerEnum == LogPlatformType.Console)
            {
                 RELog.logger = new RELog.ConsoleLogger();
            }
            else
            {
                 RELog.logger = new RELog.UnityLogger();
            }
            if (!cfg.enableSave)
            {
                return;
            }
            if (cfg.enableCover)
            {
                string path = cfg.savePath + cfg.saveName;
                try
                {
                    if (Directory.Exists(cfg.savePath))
                    {
                        if (File.Exists(path))
                        {
                            File.Delete(path);
                        }
                    }
                    else
                    {
                        Directory.CreateDirectory(cfg.savePath);
                    }
                     RELog.LogFileWriter = File.AppendText(path);
                     RELog.LogFileWriter.AutoFlush = true;
                    return;
                }
                catch (Exception)
                {
                     RELog.LogFileWriter = null;
                    return;
                }
            }
            string str = DateTime.Now.ToString("yyyyMMdd@HH-mm-ss");
            string path2 = cfg.savePath + str + cfg.saveName;
            try
            {
                if (!Directory.Exists(cfg.savePath))
                {
                    Directory.CreateDirectory(cfg.savePath);
                }
                 RELog.LogFileWriter = File.AppendText(path2);
                 RELog.LogFileWriter.AutoFlush = true;
            }
            catch (Exception)
            {
                 RELog.LogFileWriter = null;
            }
        }


        public static void Log(string msg, params object[] args)
        {
            if (! RELog.logConfig.enableLog)
            {
                return;
            }
            msg =  RELog.DecorateLog(string.Format(msg, args), false);
            string obj = "RELogLock";
            lock (obj)
            {
                 RELog.logger.Log(msg, LogColor.None);
                if ( RELog.logConfig.enableSave)
                {
                     RELog.WriteToFile(string.Format("[L]{0}", msg));
                }
            }
        }


        public static void Log(object obj)
        {
            if (! RELog.logConfig.enableLog)
            {
                return;
            }
            string text =  RELog.DecorateLog(obj.ToString(), false);
            string obj2 = "RELogLock";
            lock (obj2)
            {
                 RELog.logger.Log(text, LogColor.None);
                if ( RELog.logConfig.enableSave)
                {
                     RELog.WriteToFile(string.Format("[L]{0}", text));
                }
            }
        }


        public static void ColorLog(LogColor color, string msg, params object[] args)
        {
            if (! RELog.logConfig.enableLog)
            {
                return;
            }
            msg =  RELog.DecorateLog(string.Format(msg, args), false);
            string obj = "RELogLock";
            lock (obj)
            {
                 RELog.logger.Log(msg, color);
                if ( RELog.logConfig.enableSave)
                {
                     RELog.WriteToFile(string.Format("[L]{0}", msg));
                }
            }
        }


        public static void ColorLog(LogColor color, object obj)
        {
            if (! RELog.logConfig.enableLog)
            {
                return;
            }
            string text =  RELog.DecorateLog(obj.ToString(), false);
            string obj2 = "RELogLock";
            lock (obj2)
            {
                 RELog.logger.Log(text, color);
                if ( RELog.logConfig.enableSave)
                {
                     RELog.WriteToFile(string.Format("[L]{0}", text));
                }
            }
        }


        public static void LogRed(string msg, params object[] args)
        {
             RELog.ColorLog(LogColor.Red, msg, args);
        }


        public static void LogRed(object obj)
        {
             RELog.ColorLog(LogColor.Red, obj);
        }


        public static void LogGreen(string msg, params object[] args)
        {
             RELog.ColorLog(LogColor.Green, msg, args);
        }


        public static void LogGreen(object obj)
        {
             RELog.ColorLog(LogColor.Green, obj);
        }


        public static void LogBlue(string msg, params object[] args)
        {
             RELog.ColorLog(LogColor.Blue, msg, args);
        }


        public static void LogBlue(object obj)
        {
             RELog.ColorLog(LogColor.Blue, obj);
        }


        public static void LogCyan(string msg, params object[] args)
        {
             RELog.ColorLog(LogColor.Cyan, msg, args);
        }


        public static void LogCyan(object obj)
        {
             RELog.ColorLog(LogColor.Cyan, obj);
        }


        public static void LogMagenta(string msg, params object[] args)
        {
             RELog.ColorLog(LogColor.Magenta, msg, args);
        }


        public static void LogMagenta(object obj)
        {
             RELog.ColorLog(LogColor.Magenta, obj);
        }


        public static void LogYellow(string msg, params object[] args)
        {
             RELog.ColorLog(LogColor.Yellow, msg, args);
        }


        public static void LogYellow(object obj)
        {
             RELog.ColorLog(LogColor.Yellow, obj);
        }


        public static void Trace(string msg, params object[] args)
        {
            if (! RELog.logConfig.enableLog)
            {
                return;
            }
            msg =  RELog.DecorateLog(string.Format(msg, args),  RELog.logConfig.enableTrace);
            string obj = "RELogLock";
            lock (obj)
            {
                 RELog.logger.Log(msg, LogColor.Magenta);
                if ( RELog.logConfig.enableSave)
                {
                     RELog.WriteToFile(string.Format("[T]{0}", msg));
                }
            }
        }


        public static void Trace(object obj)
        {
            if (! RELog.logConfig.enableLog)
            {
                return;
            }
            string text =  RELog.DecorateLog(obj.ToString(),  RELog.logConfig.enableTrace);
            string obj2 = "RELogLock";
            lock (obj2)
            {
                 RELog.logger.Log(text, LogColor.Magenta);
                if ( RELog.logConfig.enableSave)
                {
                     RELog.WriteToFile(string.Format("[T]{0}", text));
                }
            }
        }


        public static void Warn(string msg, params object[] args)
        {
            if (! RELog.logConfig.enableLog)
            {
                return;
            }
            msg =  RELog.DecorateLog(string.Format(msg, args), false);
            string obj = "RELogLock";
            lock (obj)
            {
                 RELog.logger.Warn(msg);
                if ( RELog.logConfig.enableSave)
                {
                     RELog.WriteToFile(string.Format("[W]{0}", msg));
                }
            }
        }


        public static void Warn(object obj)
        {
            if (! RELog.logConfig.enableLog)
            {
                return;
            }
            string text =  RELog.DecorateLog(obj.ToString(), false);
            string obj2 = "RELogLock";
            lock (obj2)
            {
                 RELog.logger.Warn(text);
                if ( RELog.logConfig.enableSave)
                {
                     RELog.WriteToFile(string.Format("[W]{0}", text));
                }
            }
        }


        public static void Error(string msg, params object[] args)
        {
            if (! RELog.logConfig.enableLog)
            {
                return;
            }
            msg =  RELog.DecorateLog(string.Format(msg, args),  RELog.logConfig.enableTrace);
            string obj = "RELogLock";
            lock (obj)
            {
                 RELog.logger.Error(msg);
                if ( RELog.logConfig.enableSave)
                {
                     RELog.WriteToFile(string.Format("[E]{0}", msg));
                }
            }
        }


        public static void Error(object obj)
        {
            if (! RELog.logConfig.enableLog)
            {
                return;
            }
            string text =  RELog.DecorateLog(obj.ToString(),  RELog.logConfig.enableTrace);
            string obj2 = "RELogLock";
            lock (obj2)
            {
                 RELog.logger.Error(text);
                if ( RELog.logConfig.enableSave)
                {
                     RELog.WriteToFile(string.Format("[E]{0}", text));
                }
            }
        }


        private static string DecorateLog(string msg, bool isTrace = false)
        {
            StringBuilder stringBuilder = new StringBuilder( RELog.logConfig.logPrefix, 100);
            if ( RELog.logConfig.enableTime)
            {
                // string log = "*[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss dddd") + "]: " + content;
                stringBuilder.AppendFormat("{0}", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss dddd"));  //("HH:mm:ss-fff"));
            }

            stringBuilder.AppendFormat("{0}",  RELog.logConfig.logPostfix);

            if ( RELog.logConfig.enableThreadID)
            {
                stringBuilder.AppendFormat("({0})",  RELog.GetThreadID());
            }

            stringBuilder.AppendFormat("{0} {1}",  RELog.logConfig.logSeparate, msg);

            if (isTrace)
            {
                stringBuilder.AppendFormat("\nStackTrace:{0}",  RELog.GetLogTrace());
            }
            return stringBuilder.ToString();
        }


        private static string GetThreadID()
        {
            return string.Format("ThreadID:{0}", Thread.CurrentThread.ManagedThreadId);
        }


        private static string GetLogTrace()
        {
            StackTrace stackTrace = new StackTrace(3, true);
            string text = "";
            for (int i = 0; i < stackTrace.FrameCount; i++)
            {
                StackFrame frame = stackTrace.GetFrame(i);
                text += string.Format("\n    {0}::{1} Line:{2}", frame.GetFileName(), frame.GetMethod(), frame.GetFileLineNumber());
            }
            return text;
        }


        private static void WriteToFile(string msg)
        {
            if ( RELog.logConfig.enableSave &&  RELog.LogFileWriter != null)
            {
                try
                {
                     RELog.LogFileWriter.WriteLine(msg);
                }
                catch (Exception)
                {
                     RELog.LogFileWriter = null;
                }
            }
        }


        public static void PrintBytesArray(byte[] bytes, string prefix, Action<string> printer = null)
        {
            string text = prefix + "->\n";
            for (int i = 0; i < bytes.Length; i++)
            {
                if (i % 10 == 0)
                {
                    text = text + bytes[i].ToString() + "\n";
                }
                text = text + bytes[i].ToString() + " ";
            }
            if (printer != null)
            {
                printer(text);
                return;
            }
             RELog.Log(text, Array.Empty<object>());
        }


        private static ILog logger;


        public static LogConfig logConfig;


        private static StreamWriter LogFileWriter;


        private const string logLock = "RELogLock";


        private class UnityLogger : ILog
        {
            public void Log(string msg, LogColor color = LogColor.None)
            {
                if (color != LogColor.None)
                {
                    msg = this.ColorUnityLog(msg, color);
                }
                this.type.GetMethod("Log", new Type[]
                {
                    typeof(object)
                }).Invoke(null, new object[]
                {
                    msg
                });
            }

            public void Warn(string msg)
            {
                this.type.GetMethod("LogWarning", new Type[]
                {
                    typeof(object)
                }).Invoke(null, new object[]
                {
                    msg
                });
            }


            public void Error(string msg)
            {
                this.type.GetMethod("LogError", new Type[]
                {
                    typeof(object)
                }).Invoke(null, new object[]
                {
                    msg
                });
            }


            private string ColorUnityLog(string msg, LogColor color)
            {
                switch (color)
                {
                    case LogColor.Red:
                        msg = string.Format("<color=#FF0000>{0}</color>", msg);
                        break;
                    case LogColor.Green:
                        msg = string.Format("<color=#00FF00>{0}</color>", msg);
                        break;
                    case LogColor.Blue:
                        msg = string.Format("<color=#0000FF>{0}</color>", msg);
                        break;
                    case LogColor.Cyan:
                        msg = string.Format("<color=#00FFFF>{0}</color>", msg);
                        break;
                    case LogColor.Magenta:
                        msg = string.Format("<color=#FF00FF>{0}</color>", msg);
                        break;
                    case LogColor.Yellow:
                        msg = string.Format("<color=#FFFF00>{0}</color>", msg);
                        break;
                }
                return msg;
            }


            private Type type = Type.GetType("UnityEngine.Debug, UnityEngine");
        }


        private class ConsoleLogger : ILog
        {

            public void Log(string msg, LogColor color = LogColor.None)
            {
                this.WriteConsoleLog(msg, color);
            }


            public void Warn(string msg)
            {
                this.WriteConsoleLog(msg, LogColor.Yellow);
            }


            public void Error(string msg)
            {
                this.WriteConsoleLog(msg, LogColor.Red);
            }


            private void WriteConsoleLog(string msg, LogColor color)
            {
                switch (color)
                {
                    case LogColor.Red:
                        Console.ForegroundColor = ConsoleColor.DarkRed;
                        Console.WriteLine(msg);
                        Console.ForegroundColor = ConsoleColor.Gray;
                        return;
                    case LogColor.Green:
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine(msg);
                        Console.ForegroundColor = ConsoleColor.Gray;
                        return;
                    case LogColor.Blue:
                        Console.ForegroundColor = ConsoleColor.Blue;
                        Console.WriteLine(msg);
                        Console.ForegroundColor = ConsoleColor.Gray;
                        return;
                    case LogColor.Cyan:
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        Console.WriteLine(msg);
                        Console.ForegroundColor = ConsoleColor.Gray;
                        return;
                    case LogColor.Magenta:
                        Console.ForegroundColor = ConsoleColor.Magenta;
                        Console.WriteLine(msg);
                        Console.ForegroundColor = ConsoleColor.Gray;
                        return;
                    case LogColor.Yellow:
                        Console.ForegroundColor = ConsoleColor.DarkYellow;
                        Console.WriteLine(msg);
                        Console.ForegroundColor = ConsoleColor.Gray;
                        return;
                }
                Console.WriteLine(msg);
            }
        }

        #endregion

        #region 不需要初始化就可与使用

        public static bool CanDebug = true;
        public static Action<object, LogType> DebugCallBack = null;
        public static void Debug(object message, LogType logType = LogType.Normal)
        {
            if (CanDebug == true)
            {
                if (DebugCallBack != null)
                {
                    DebugCallBack(message, logType);
                }
                else
                {
                    string log = $"*[" + DateTime.Now.ToString() + "](ThreadID:" + Thread.CurrentThread.ManagedThreadId.ToString() + ")>>" + message;

                    switch (logType)
                    {
                        case LogType.Normal:
                            Console.WriteLine(log);
                            break;
                        case LogType.Accent:
                            Console.ForegroundColor = ConsoleColor.Green;
                            Console.WriteLine(log);
                            Console.ForegroundColor = ConsoleColor.Gray;
                            break;
                        case LogType.Warning:
                            Console.ForegroundColor = ConsoleColor.DarkYellow;
                            Console.WriteLine(log);
                            Console.ForegroundColor = ConsoleColor.Gray;
                            break;
                        case LogType.Error:
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine(log);
                            Console.ForegroundColor = ConsoleColor.Gray;
                            break;
                        case LogType.None:
                            break;
                    }
                }
            }
        }
        #endregion
    }
}