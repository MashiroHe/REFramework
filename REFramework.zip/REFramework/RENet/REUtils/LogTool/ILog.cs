﻿/********************************************************************
version:  1.0.2
created:  2024/03/20 11:54
filename: ILog.cs
author:	  Mashiro
e-mail:   1967407707@qq.com
purpose:   
********************************************************************/

namespace REUtils.LogTool
{
    internal interface ILog
    {

        void Log(string msg, LogColor logColor = LogColor.None);


        void Warn(string msg);


        void Error(string msg);
    }
}
