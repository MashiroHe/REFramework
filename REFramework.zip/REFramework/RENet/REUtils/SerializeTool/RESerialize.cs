﻿/********************************************************************
version:  1.0.2
created:  2024/03/20 11:54
filename: SerializeTools.cs
author:	  Mashiro
e-mail:   1967407707@qq.com
purpose:   
********************************************************************/
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;
using REUtils.LogTool;
using ProtoBuf;

namespace REUtils.SerializeTool
{
    public class RESerialize
    {
        #region Serialize Method

        /*普通序列化方式函数*/
        public static byte[] SerializeMsg<TMsg>(TMsg msg)
        {
            byte[] array = null;
            using (MemoryStream memoryStream = new MemoryStream())
            {
                try
                {
                    BinaryFormatter binaryFormatter = new BinaryFormatter();
                    binaryFormatter.Serialize(memoryStream, msg);
                    memoryStream.Seek(0, SeekOrigin.Begin);
                    array = memoryStream.ToArray();

                }
                catch (SerializationException ex)
                {
                    string str = "RENet序列化网络消息失败：";
                    SerializationException ex2 = ex;
                     RELog.Debug(str + ((ex2 != null) ? ex2.ToString() : null), LogType.Normal);
                }
            }
            return array;
        }

        public static TMsg DeserializeMsg<TMsg>(byte[] datas)
        {
            TMsg tmsg = default(TMsg);
            using (MemoryStream memoryStream = new MemoryStream(datas))
            {
                try
                {
                    BinaryFormatter binaryFormatter = new BinaryFormatter();
                    memoryStream.Seek(0, SeekOrigin.Begin);
                    tmsg = (TMsg)(binaryFormatter.Deserialize(memoryStream));

                }
                catch (SerializationException ex)
                {
                    string str = "RENet反序列化网络消息失败：";
                    SerializationException ex2 = ex;
                     RELog.Debug(str + ((ex2 != null) ? ex2.ToString() : null));

                }
            }
            return tmsg;
        }

        /*Protobuffer序列化方式函数 protobuf-net(3.2.30)*/
        public static byte[] SerializeProtoMsg<TMsg>(TMsg msg)
        {
            byte[] array = null;
            using (MemoryStream memoryStream = new MemoryStream())
            {
                try
                {
                    Serializer.Serialize(memoryStream, msg);

                    //array=new byte[memoryStream.Length];
                    //Buffer.BlockCopy(memoryStream.GetBuffer(), 0, array, 0, (int)memoryStream.Length);

                    memoryStream.Seek(0, SeekOrigin.Begin);
                    array = memoryStream.ToArray();
                }
                catch (SerializationException ex)
                {
                    string str = "RENet序列化网络消息失败：";
                    SerializationException ex2 = ex;
                     RELog.Debug(str + ((ex2 != null) ? ex2.ToString() : null));
                }
            }
            return array;
        }
        public static TMsg DeserializeProtoMsg<TMsg>(byte[] datas)
        {
            TMsg tmsg = default(TMsg);
            using (MemoryStream memoryStream = new MemoryStream(datas))
            {
                try
                {
                    tmsg = Serializer.Deserialize<TMsg>(memoryStream);
                }
                catch (SerializationException ex)
                {
                    string str = "RENet反序列化网络消息失败：";
                    SerializationException ex2 = ex;
                     RELog.Debug(str + ((ex2 != null) ? ex2.ToString() : null));

                }
            }
            return tmsg;
        }

        public static void SerializeProtoMsgToFile<TMsg>(TMsg msg, string fileName)
        {
            using (FileStream fileStream = File.Create(fileName + ".bytes"))
            {
                try
                {
                    Serializer.Serialize<TMsg>(fileStream, msg);
                }
                catch (SerializationException ex)
                {
                    string str = "SerializeProtoMsgToFile 失败：";
                    SerializationException ex2 = ex;
                     RELog.Debug(str + ((ex2 != null) ? ex2.ToString() : null));
                }
            }
        }
        public static TMsg DeserializeFileToProtoMsg<TMsg>(string fileName)
        {
            TMsg tmsg = default(TMsg);
            using (FileStream fileStream = File.OpenRead(fileName + ".bytes"))
            {
                try
                {
                    tmsg = Serializer.Deserialize<TMsg>(fileStream);
                }
                catch (SerializationException ex)
                {
                    string str = "DeserializeFileToProtoMsg 失败：";
                    SerializationException ex2 = ex;
                     RELog.Debug(str + ((ex2 != null) ? ex2.ToString() : null));
                }
            }
            return tmsg;
        }
        #endregion

    }
}
