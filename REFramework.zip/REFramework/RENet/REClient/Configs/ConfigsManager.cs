﻿/*********************************************************************
created:  2024/03/18 10:08
filename: Launch.cs
author:	  Mashiro
e-mail:   1967407707@qq.com
purpose:   
********************************************************************/
using LitJson;
using REUtils.LogTool;

namespace REClient.Configs
{
    public class ConfigsManager
    {
        private static ConfigsManager m_Single;
        public static ConfigsManager Single
        {
            get
            {
                if (m_Single == null)
                {
                    m_Single = new ConfigsManager();
                }
                return m_Single;
            }
        }

        public bool IsUseTCP { get => m_IsUseTCP; }
        public string IPAddress { get => m_IPAddress; set => m_IPAddress = value; }
        public int Port { get => m_Port; set => m_Port = value; }
        public int ListenCount { get => m_ListenCount; set => m_ListenCount = value; }
        public bool IsParseFinished { get => m_IsParseFinished; set => m_IsParseFinished = value; }

        #region
        private string m_IPConfigPath = @"..\..\..\Configs\IPAddress\IPConfig.txt";// AppDomain.CurrentDomain.BaseDirectory + @"Config\IPConfig.txt";

        public string IPConfigPath
        {
            get => m_IPConfigPath;
        }
      

        /*右键引用 打开管理netget程序包，在联机里面搜索litjson,在搜索结果里面选择一个，点击安装
* 使用JsonMapper解析json数据
[
{"IPAddress":192.168.1.100,"Port":17666,"ListenCount":100}
]
*/

        private bool m_IsUseTCP = true;

        private string m_IPAddress = null;
        private int m_Port;
        private int m_ListenCount;
        private bool m_IsParseFinished = false;
        #endregion
        public void Init()
        {
            RELog.Log("初始化 配置文件IPConfig.txt...");
            IsParseFinished = false;
             RELog.Log(m_IPConfigPath);
            //读取IPAddress配置文件
            if (File.Exists(m_IPConfigPath) == true)
            {
                //首先初始化 读取IP地址配置文件
                JsonData jsonData = JsonMapper.ToObject(File.ReadAllText(m_IPConfigPath));//注意这里返回的是一个数组

                foreach (JsonData temp in jsonData)
                {
                    JsonData ipAddressData = temp["IPAddress"];//通过字符串索引器获取键对应的值
                    JsonData portData = temp["Port"];
                    JsonData listenCountData = temp["ListenCount"];

                    JsonData serverType = temp["ServerType"];

                    m_IPAddress = ipAddressData.ToString();
                    m_Port = Int32.Parse(portData.ToString());
                    m_ListenCount = Int32.Parse(listenCountData.ToString());

                    m_IsUseTCP= serverType.ToString().ToLower()=="tcp"?true:false;
                }
                 RELog.Log("初始化 配置文件完成！");
                IsParseFinished = true;
            }
            else
            {
                 RELog.Log("IPConfigPath don't exist");
            }
        }
    }
}
