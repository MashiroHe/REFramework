﻿using REClient.Configs;
using RENet.TCP;
using REProtocol;
using REUtils.LogTool;

namespace REClient.TCP
{
    public class Root
    {
        private static Root m_Single=null;
        public static Root Single
        {
            get
            {
                if (m_Single == null)
                {
                    m_Single = new Root();
                }
                return m_Single;
            }
        }

        #region Private Field

        private ConfigsManager m_ConfigsManager = null;
        private RESocket<Session, MsgPack> m_Client = null;
        #endregion

        public void Init()
        {
            RELog.Log("Init REClient.TCP 客户端...");
            m_ConfigsManager = ConfigsManager.Single;
            if (m_ConfigsManager != null && m_ConfigsManager.IsParseFinished)
            {
                m_Client = new RESocket<Session, MsgPack>();

                m_Client.InitAsClient(m_ConfigsManager.IPAddress, m_ConfigsManager.Port);
            }

            RELog.Log("Init REClient.TCP 客户端完成!");
        }

        private void Logout()
        {
            if (m_Client != null)
            {
                m_Client.Dispose(false);
                m_Client = null;
                //重新初始化连接服务器
                Init();
            }
        }


        #region Public Method

        public void SendRequestLogin()
        {
            MsgBody msgBody = new MsgBody();
            msgBody.RequestLoginMsg = new RequestLoginMsg() { Account = "Shiina", Password = "123456", ServerID = 001 };

            SendMsg(Command.RequestLoginMsg, msgBody);
        }

        public void SendRequestBag()
        {
            MsgBody msgBody = new MsgBody();
            msgBody.RequestBagMsg = new RequestBagMsg() { ServerID = 001, UserID = 1234 };

            SendMsg(Command.RequestBagMsg, msgBody);
        }



        public void SendMsg(Command commandType, MsgBody msgBody)
        {
            MsgPack msgPack = CreateMsgPack(commandType, msgBody);
            SendMsgAsync(msgPack);
        }
     

        #endregion

        #region Private Method
        private void SendMsgAsync(MsgPack msg)
        {
            if (m_Client != null && m_Client.Session != null)
            {
                m_Client.Session.SendMsgAsync(msg);
            }
        }
      

        private MsgPack CreateMsgPack(Command commandType, MsgBody msgBody, int errorType = 0, int sequenceType = 0)
        {
            MsgHead head = new MsgHead();
            head.CommandType = commandType;
            head.SequenceType = sequenceType;
            head.ErrorType = errorType;

            MsgPack msgPack = new MsgPack();
            msgPack.MsgHead = head;
            msgPack.MsgBody = msgBody;
            return msgPack;
        }
        #endregion

    }
}
