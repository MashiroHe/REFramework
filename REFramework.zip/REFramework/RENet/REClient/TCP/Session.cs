﻿using REClient.Handlers;
using RENet.TCP;
using REProtocol;
using REUtils.LogTool;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace REClient.TCP
{
    public class Session : RESession<MsgPack>
    {
        protected override void OnConnected()
        {
            RELog.Log("REClient Connected!", LogType.Accent);
        }

        protected override void OnDisConnected()
        {
            RELog.Log("REClient DisConnected!", LogType.Warning);
        }
        protected override void OnRecivedMsg(MsgPack msgPack)
        {
            switch (msgPack.MsgHead.CommandType)
            {
                case Command.ResponseLoginMsg:
                    LoginHandler.HandleResponseLogin(msgPack.MsgBody);
                    break;

                case Command.ResponseBagMsg:
                    BagHandler.HandleResponseBag(msgPack.MsgBody);
                    break;

                case Command.None:
                    break;
            }
            RELog.Log(" REClient HandleMsg:" + (msgPack.MsgHead.CommandType).ToString());

        }
    }
}
