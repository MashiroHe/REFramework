﻿/*********************************************************************
created:  2024/03/18 10:08
filename: Root.cs
author:	  Mashiro
e-mail:   1967407707@qq.com
purpose:   
********************************************************************/
using REClient.Configs;
using REUtils.LogTool;
using REProtocol;
using RENet.UDP;
using System.Net;

namespace REClient.UDP
{
    public class Root
    {
        private static Root m_Single = null;
        public static Root Single
        {
            get
            {
                if (m_Single == null)
                {
                    m_Single = new Root();
                }
                return m_Single;
            }
        }

        private RESocket<Session, MsgPack> m_Client = null;
        private IPEndPoint m_ServerIPEndPoint = null;
        private ConfigsManager m_ConfigsManager=null;
        public void Init()
        {
             RELog.Log("Init REClient.UDP 客户端...");
            m_ConfigsManager = ConfigsManager.Single;
            if (m_ConfigsManager != null)
            {
                int port = m_ConfigsManager.Port;
                string ipAddress = m_ConfigsManager.IPAddress;

                IPAddress address = IPAddress.Parse(ipAddress);
                m_ServerIPEndPoint= new IPEndPoint(address, port);

                m_Client = new RESocket<Session,MsgPack>(0);//默认为0 系统随机分配客户端口号
                m_Client.Init(false);
            }

            RELog.Log("Init REClient.UDP 客户端完成");
        }

        private void SendMsg(Command commandType, MsgBody msgBody)
        {
            MsgHead head = new MsgHead();
            head.CommandType = commandType;
            head.SequenceType = 1;
            head.ErrorType = 0;

            MsgPack msgPack = new MsgPack();
            msgPack.MsgHead = head;
            msgPack.MsgBody = msgBody;

            m_Client.Session.SendMsg(msgPack,m_ServerIPEndPoint);
        }

        public void SendRequestLogin()
        {
            MsgBody msgBody = new MsgBody();
            msgBody.RequestLoginMsg = new RequestLoginMsg() { Account = "Shiina", Password = "123456", ServerID = 001 };

            SendMsg(Command.RequestLoginMsg, msgBody);
        }

        public void SendRequestBag()
        {
            MsgBody msgBody = new MsgBody();
            msgBody.RequestBagMsg = new RequestBagMsg() { ServerID = 001, UserID = 1234 };

            SendMsg(Command.RequestBagMsg, msgBody);
        }
    }
}
