﻿using REClient.Handlers;
using RENet.UDP;
using REProtocol;
using REUtils.LogTool;
using System.Net;
namespace REClient.UDP
{
    public class Session : RESession<MsgPack>
    {
        protected override void OnConnected()
        {
            RELog.Log("REClient Connected!", LogType.Accent);
        }

        protected override void OnDisConnected()
        {
            RELog.Log("REClient DisConnected!", LogType.Warning);
        }
        protected override void OnRecivedMsg(MsgPack msgPack, IPEndPoint iPEndPoint)
        {
            switch (msgPack.MsgHead.CommandType)
            {
                case Command.ResponseLoginMsg:
                    LoginHandler.HandleResponseLogin(msgPack.MsgBody);
                    break;

                case Command.ResponseBagMsg:
                    BagHandler.HandleResponseBag(msgPack.MsgBody);
                    break;
                case Command.None:
                    break;
                default:
                    break;
            }
            RELog.Log("REClient HandleMsg:" + (msgPack.MsgHead.CommandType).ToString());
        }
    }

}
