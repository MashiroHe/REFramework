﻿/*********************************************************************
created:  2024/03/18 10:08
filename: Launch.cs
author:	  Mashiro
e-mail:   1967407707@qq.com
purpose:   
********************************************************************/
using REClient.Configs;
using REUtils.LogTool;


namespace REClient
{
    public class Launch
    {
        static void Main(string[] args)
        {
            RELog.Init(LogPlatformType.Console);
            //首先，初始化配置文件
            ConfigsManager.Single.Init();

            if (ConfigsManager.Single.IsUseTCP == false)
            {
                //然后初始化 启动服务器 
                REClient.UDP.Root.Single.Init();

                while (true)
                {
                    string input = Console.ReadLine();
                    if (input != null)
                    {
                        if (input == "Login")
                        {
                            REClient.UDP.Root.Single.SendRequestLogin();
                        }
                        else if (input == "Bag")
                        {
                            REClient.UDP.Root.Single.SendRequestBag();
                        }
                        else
                        {
                            RELog.ColorLog(LogColor.Red, "Undifined");
                        }
                    }
                }
            }
            else
            {
                REClient.TCP.Root.Single.Init();

                while (true)
                {
                    string input = Console.ReadLine();
                    if (input != null)
                    {
                        if (input == "Login")
                        {
                            REClient.TCP.Root.Single.SendRequestLogin();
                        }
                        else if (input == "Bag")
                        {
                            REClient.TCP.Root.Single.SendRequestBag();
                        }
                        else
                        {
                            RELog.ColorLog(LogColor.Red, "Undifined");
                        }
                    }
                }
            }
            Console.ReadKey();
        }
    }
}