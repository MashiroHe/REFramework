﻿/*********************************************************************
created:  2024/03/18 10:08
filename: Root.cs
author:	  Mashiro
e-mail:   1967407707@qq.com
purpose:   
********************************************************************/
using REProtocol;
using REUtils.LogTool;

namespace REClient.Handlers
{
    public class LoginHandler
    {
        public static void HandleResponseLogin(MsgBody msgBody)
        {
            ResponseLoginMsg msg = msgBody.ResponseLoginMsg;
            if (msg != null)
            {
                RELog.Log("Server Response LoginMsg:" + msg.UserData.Id + "/" + msg.UserData.Name + "/" + msg.UserData.Level);
            }
        }

    }
}
