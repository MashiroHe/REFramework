﻿/*********************************************************************
created:  2024/03/18 10:08
filename: Root.cs
author:	  Mashiro
e-mail:   1967407707@qq.com
purpose:   
********************************************************************/
using REProtocol;
using REUtils.LogTool;


namespace REClient.Handlers
{
    public class BagHandler
    {
        public static void HandleResponseBag(MsgBody msgBody)
        {
            ResponseBagMsg msg = msgBody.ResponseBagMsg;
            if (msg != null)
            {
                RELog.Log("Server Response Bag Msg:" + msg.IsSuccess + "/" + msg.BagItems.Count);

                if (msg.BagItems.Count > 0)
                {
                    foreach (var bagItem in msg.BagItems)
                    {
                        RELog.Log("Bag:" + bagItem.Count + "/" + bagItem.Id + "/" + bagItem.Level);
                    }
                }
            }
        }
    }
}
