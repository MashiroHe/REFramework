﻿
using System.Net.Sockets;
using System.Net;

using REServer.Configs;
using REUtils.LogTool;
using REUtils.SerializeTool;
using REServer.Handlers;
using REProtocol;
using RENet.UDP;


namespace REServer.UDP
{
    public class Root
    {
        private static Root m_Single = null;
        public static Root Single
        {
            get
            {
                if (m_Single == null)
                {
                    m_Single = new Root();
                }
                return m_Single;
            }
        }

        private RESocket<Session, MsgPack> m_Server = null;
        private IPEndPoint m_ServerIPEndPoint = null;

        private ConfigsManager m_ConfigsManager = null;

        public void Init()
        {
            RELog.Log("Init REServer.UDP 服务器...");
            m_ConfigsManager = ConfigsManager.Single;
            if (m_ConfigsManager != null)
            {
                int port = m_ConfigsManager.Port;
                string ipAddress = m_ConfigsManager.IPAddress;

                IPAddress address = IPAddress.Parse(ipAddress);
                m_ServerIPEndPoint = new IPEndPoint(address, port);

                m_Server = new RESocket<Session,MsgPack>(m_ServerIPEndPoint);
                m_Server.Init();
            }

            RELog.Log("Init REServer.UDP 服务器完成！");
        }

        public void SendMsg(Command commandType, MsgBody msgBody, IPEndPoint iPEndPoint)
        {
            MsgHead head = new MsgHead();
            head.CommandType = commandType;
            head.SequenceType = 1;
            head.ErrorType = 0;

            MsgPack msgPack = new MsgPack();
            msgPack.MsgHead = head;
            msgPack.MsgBody = msgBody;

            m_Server.Session.SendMsg(msgPack, iPEndPoint);
        }
    }

}
