﻿
using RENet.UDP;
using REProtocol;
    using REServer.Handlers;
    using REUtils.LogTool;
using System.Net;

namespace REServer.UDP
    {
        public class Session : RESession<MsgPack>
        {
            protected override void OnConnected()
            {
                RELog.Log("REServer Connected!", LogType.Accent);
            }

            protected override void OnDisConnected()
            {
                RELog.Log("REServer DisConnected!", LogType.Warning);
            }
            protected override void OnRecivedMsg(MsgPack msgPack, IPEndPoint iPEndPoint)
            {
                switch (msgPack.MsgHead.CommandType)
                {
                    case Command.RequestLoginMsg:
                        LoginHandler.HandleRequestLogin(msgPack.MsgBody, iPEndPoint);
                        break;
                    case Command.RequestBagMsg:
                        BagHandler.HandleRequestBag(msgPack.MsgBody, iPEndPoint);
                        break;
                    case Command.None:
                        break;
                    default:
                        break;
                }
                RELog.Log("REServer HandleMsg:" + (msgPack.MsgHead.CommandType).ToString());
            }
        }

    }

