﻿/********************************************************************
created:  2024/03/11  10:00
filename: Root.cs
author:	  Mashiro 
e-mail address:1967407707@qq.com
purpose:    
********************************************************************/
using RENet.TCP;
using REProtocol;
using REServer.Configs;
using REUtils.LogTool;
using REUtils.SerializeTool;
using System.Data;
using System.Net;

namespace REServer.TCP
{
    public class Root
    {
        private static Root m_Single;
        public static Root Single
        {
            get
            {
                if (m_Single == null)
                {
                    m_Single = new Root();
                }
                return m_Single;
            }
        }

        #region Private Field

        private RESocket<Session, MsgPack> m_Server = null;

        private ConfigsManager m_ConfigsManager = null;
        #endregion

        public void Init()
        {
            RELog.Log("Init REServer.TCP 服务器...");
            m_ConfigsManager = ConfigsManager.Single;
            if (m_ConfigsManager != null && m_ConfigsManager.IsParseFinished)
            {
                m_Server = new RESocket<Session, MsgPack>();

                m_Server.InitAsServer(m_ConfigsManager.IPAddress, m_ConfigsManager.Port, m_ConfigsManager.ListenCount);
            }

            RELog.Log("Init REServer.TCP 服务器完成！");
        }

        #region Public Method

        public void SendMsg(Command commandType, MsgBody msgBody)
        {
            MsgPack msgPack = CreateMsgPack(commandType, msgBody);
            SendMsgAsync(msgPack);
        }
        public void SendMsgToAll(Command commandType, MsgBody msgBody)
        {
            MsgPack msgPack =  CreateMsgPack(commandType, msgBody);
            SendMsgToAllAsync(msgPack);
        }

        #endregion

        #region Private Method
        private void SendMsgAsync(MsgPack msg)
        {
            if (m_Server != null && m_Server.Session != null)
            {
                m_Server.Session.SendMsgAsync(msg);
            }
        }
        private void SendMsgToAllAsync(MsgPack msg)
        {
            if (m_Server != null && m_Server.Session != null)
            {
                m_Server.Session.SendMsgToAll(m_Server.Sessions, msg);
            }
        }

        private MsgPack CreateMsgPack(Command commandType, MsgBody msgBody,int errorType=0,int sequenceType=0)
        {
            MsgHead head = new MsgHead();
            head.CommandType = commandType;
            head.SequenceType = sequenceType;
            head.ErrorType = errorType;

            MsgPack msgPack = new MsgPack();
            msgPack.MsgHead = head;
            msgPack.MsgBody = msgBody;
            return msgPack;
        }
        #endregion
    }
}
