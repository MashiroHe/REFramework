﻿using RENet.TCP;
using REProtocol;
using REServer.Handlers;
using REUtils.LogTool;
using System.Net;

namespace REServer.TCP
{
    public class Session : RESession<MsgPack>
    {
        protected override void OnConnected()
        {
            RELog.Log("REServer Connected!", LogType.Accent);
        }

        protected override void OnDisConnected()
        {
            RELog.Log("REServer DisConnected!", LogType.Warning);
        }
        protected override void OnRecivedMsg(MsgPack msgPack)
        {
            switch (msgPack.MsgHead.CommandType)
            {
                case Command.RequestLoginMsg:
                    LoginHandler.HandleRequestLogin(msgPack.MsgBody,null);
                    break;
             
                case Command.RequestBagMsg:
                    BagHandler.HandleRequestBag(msgPack.MsgBody, null);
                    break;
             
                case Command.None:
                    break;
            }
            RELog.Log("REServer HandleMsg:" + (msgPack.MsgHead.CommandType).ToString());
        }
    }

}
