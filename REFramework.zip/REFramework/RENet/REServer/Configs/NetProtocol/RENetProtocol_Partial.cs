﻿/********************************************************************
created:  2024/03/15  15:17
filename: NetMsg.cs
author:	  Mashiro 
e-mail:   1967407707@qq.com
purpose: 
********************************************************************/

using RENet.TCP;

namespace REProtocol
{
    [Serializable]
    public partial class MsgPack { }

    [Serializable]
    public partial class MsgHead { }

    [Serializable]
    public partial class MsgBody { }

    [Serializable]
    public partial class RequestLoginMsg { }

    [Serializable]
    public partial class ResponseLoginMsg { }

    [Serializable]
    public partial class UserData { }

    [Serializable]
    public partial class RequestBagMsg { }

    [Serializable]
    public partial class ResponseBagMsg { }

    [Serializable]
    public partial class BagItemData { }
}
