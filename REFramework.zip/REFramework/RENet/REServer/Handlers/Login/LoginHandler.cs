﻿using REProtocol;
using REServer.Configs;
using REUtils.LogTool;
using System.Net;

namespace REServer.Handlers
{
    public class LoginHandler
    {
        public static void HandleRequestLogin(MsgBody msgBody, IPEndPoint iPEndPoint)
        {
            RequestLoginMsg msg = msgBody.RequestLoginMsg;
            if (msg != null)
            {
                RELog.Log("Client RequestLoginMsg:" + msg.Account + "/" + msg.Password + "/" + msg.ServerID);

                //回复客户端请求登录
                UserData userData = new UserData();
                userData.Exp = 2;
                userData.Level = 3;
                userData.Name = "Mashiro";
                userData.Id = 001;

                MsgBody body = new MsgBody();
                body.ResponseLoginMsg = new ResponseLoginMsg()
                {
                    UserData = userData
                };

                if (ConfigsManager.Single.IsTCP == false)
                {
                    REServer.UDP.Root.Single.SendMsg(Command.ResponseLoginMsg, body, iPEndPoint);
                }
                else
                {
                    REServer.TCP.Root.Single.SendMsg(Command.ResponseLoginMsg, body);
                }
            }
        }
    }
}
