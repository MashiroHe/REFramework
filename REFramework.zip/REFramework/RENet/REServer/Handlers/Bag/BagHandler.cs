﻿/*********************************************************************
created:  2024/03/18 14:21
filename: BagHandler.cs
author:	  Mashiro
e-mail:   1967407707@qq.com
purpose:   
********************************************************************/
using REProtocol;
using REServer.Configs;
using REServer.UDP;
using REUtils.LogTool;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace REServer.Handlers
{
    public class BagHandler
    {
        public static void HandleRequestBag(MsgBody msgBody, IPEndPoint iPEndPoint)
        {
            RequestBagMsg msg = msgBody.RequestBagMsg;
            if (msg != null)
            {
                RELog.Log("Client RequestBagMsg:" + msg.UserID + "/" + msg.ServerID);

                //回复客户端请求登录
                BagItemData itemData1 = new BagItemData();
                itemData1.Id = 1001;
                itemData1.Count = "20";
                itemData1.Level = "20";

                BagItemData itemData2 = new BagItemData();
                itemData2.Id = 1002;
                itemData2.Count = "10";
                itemData2.Level = "3";


                MsgBody body = new MsgBody();
                body.ResponseBagMsg = new ResponseBagMsg()
                {
                    IsSuccess = true,
                };
                body.ResponseBagMsg.BagItems.Add(itemData1);
                body.ResponseBagMsg.BagItems.Add(itemData2);

             
                if (ConfigsManager.Single.IsTCP == false)
                {
                    REServer.UDP.Root.Single.SendMsg(Command.ResponseBagMsg, body, iPEndPoint);
                }
                else
                {
                    REServer.TCP.Root.Single.SendMsg(Command.ResponseBagMsg, body);
                }
            }
        }

    }

}
