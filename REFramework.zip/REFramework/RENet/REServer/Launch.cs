﻿/*********************************************************************
created:  2024/03/18 10:08
filename: Root.cs
author:	  Mashiro
e-mail:   1967407707@qq.com
purpose:   
********************************************************************/
using REServer.Configs;
using REUtils.LogTool;

namespace REServer
{
    public class Launch
    {
        static void Main(string[] args)
        {
            RELog.Init(LogPlatformType.Console);
            //首先，初始化配置文件
            ConfigsManager.Single.Init();
            
            RELog.Log("启动 RESever ");
            //REServer.UDP
            if (ConfigsManager.Single.IsTCP == false)
            {
                //然后初始化 启动服务器 
                REServer.UDP.Root.Single.Init();
                while (true)
                {
                    Thread.Sleep(10);
                }
            }
            //  REServer.TCP
            else
            {
              
                //调用聊天服务器单例,初始化
                REServer.TCP.Root.Single.Init();
                //延迟调用
                while (true)
                {
                    Thread.Sleep(10);
                }
            }

            Console.ReadKey();
        }
    }
    
}
